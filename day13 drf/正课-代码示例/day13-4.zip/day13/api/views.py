import uuid
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.request import Request
from api import models
from ext import code
from ext.per import UserPermission, BossPermission, ManagerPermission
from ext.view import NbApiView
from ext.throttle import IpThrottle, UserThrottle


class LoginView(APIView):
    throttle_classes = [IpThrottle, ]
    authentication_classes = []

    def post(self, request):
        # 1.接收用户POST提交的用户名和密码
        # print(request.query_params)
        user = request.data.get("username")
        pwd = request.data.get("password")

        # 2.数据库校验
        user_object = models.UserInfo.objects.filter(username=user, password=pwd).first()
        if not user_object:
            return Response({"status": False, 'msg': "用户名或密码错误"})

        # 3.正确
        token = str(uuid.uuid4())
        user_object.token = token
        user_object.save()

        return Response({"status": True, 'data': token})


class UserView(NbApiView):
    # 经理、总监、用户
    permission_classes = [BossPermission, ManagerPermission, UserPermission]

    def get(self, request):
        print(request.user, request.auth)
        return Response("UserView")

    def post(self, request):
        print(request.user, request.auth)
        return Response("UserView")


class OrderView(NbApiView):
    # authentication_classes = [...]
    # 经理 或 总监
    permission_classes = [BossPermission, ManagerPermission]
    throttle_classes = [UserThrottle, IpThrottle]

    def get(self, request):
        print(request.user, request.auth)
        self.dispatch
        return Response({"status": True, "data": [11, 22, 33, 44]})


class AvatarView(NbApiView):
    # 总监 或 员工
    permission_classes = [BossPermission, UserPermission]
    throttle_classes = [UserThrottle, ]

    def get(self, request):
        print(request.user, request.auth)
        return Response({"status": True, "data": [11, 22, 33, 44]})

    def initialize_request(self, request, *args, **kwargs):
        # super().initialize_request()
        parser_context = self.get_parser_context(request)
        return Request(
            request,
            parsers=self.get_parsers(),
            authenticators=self.get_authenticators(),
            negotiator=self.get_content_negotiator(),
            parser_context=parser_context
        )
