from rest_framework.authentication import BaseAuthentication
from rest_framework.exceptions import AuthenticationFailed

from api import models


class QueryParamsAuthentication(BaseAuthentication):
    def authenticate(self, request):
        token = request.query_params.get("token")
        if not token:
            return

        user_object = models.UserInfo.objects.filter(token=token).first()
        if user_object:
            return user_object, token  # request.user = 用户对象; request.auth = token

    def authenticate_header(self, request):
        # return 'Basic realm="API"'
        return "API"


class HeaderAuthentication(BaseAuthentication):
    def authenticate(self, request):
        token = request.META.get("HTTP_AUTHORIZATION")
        if not token:
            return
        user_object = models.UserInfo.objects.filter(token=token).first()
        if user_object:
            return user_object, token  # request.user = 用户对象; request.auth = token

        return

    def authenticate_header(self, request):
        # return 'Basic realm="API"'
        return "API"


class NoAuthentication(BaseAuthentication):
    def authenticate(self, request):
        raise AuthenticationFailed({"status": False, 'msg': "认证失败"})

    def authenticate_header(self, request):
        return "API"
