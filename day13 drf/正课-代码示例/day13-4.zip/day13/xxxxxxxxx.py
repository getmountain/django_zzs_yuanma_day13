class HttpRequest(object):
    def __init__(self):
        pass

    def v1(self):
        print("v1")

    def v2(self):
        print("v2")


class Request(object):
    def __init__(self, req, xx):
        self._request = req
        self.xx = xx

    # 对象中有的成员，不会触发
    # 对象中无的成员，会触发
    def __getattr__(self, attr):
        # attr = "v1"
        try:
            return getattr(self._request, attr) # self._request.v1
        except AttributeError:
            return self.__getattribute__(attr)

req = HttpRequest()
req.v1()
req.v2()

request = Request(req, 111)
request.xx
request._request

request.v1()
