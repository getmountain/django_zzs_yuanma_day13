import uuid
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.request import Request
from api import models
from ext import code


class LoginView(APIView):
    authentication_classes = []

    def post(self, request):
        # 1.接收用户POST提交的用户名和密码
        # print(request.query_params)
        user = request.data.get("username")
        pwd = request.data.get("password")

        # 2.数据库校验
        user_object = models.UserInfo.objects.filter(username=user, password=pwd).first()
        if not user_object:
            return Response({"status": False, 'msg': "用户名或密码错误"})

        # 3.正确
        token = str(uuid.uuid4())
        user_object.token = token
        user_object.save()

        return Response({"status": True, 'data': token})


class UserView(APIView):
    def get(self, request):
        print(request.user, request.auth)
        return Response("UserView")

    def post(self, request):
        print(request.user, request.auth)
        return Response("UserView")


class OrderView(APIView):
    def get(self, request):
        print(request.user, request.auth)
        return Response("OrderView")
