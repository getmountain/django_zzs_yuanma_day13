from rest_framework.views import APIView
from rest_framework.response import Response
from ext.auth import CommonAuthentication


class UserView(APIView):
    authentication_classes = []

    def get(self, request):
        return Response("用户信息")


class OrderView(APIView):
    authentication_classes = [CommonAuthentication, ]

    def get(self, request):
        if request.user:
            message = f"{request.user}的订单信息"
        else:
            message = "公共订单信息"
        return Response(message)


class InfoView(APIView):
    def get(self, request):
        message = f"{request.user}的用户信息"
        return Response(message)
