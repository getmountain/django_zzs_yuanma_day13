from rest_framework.views import APIView
from rest_framework.response import Response


class UserView(APIView):
    def get(self, request, version, pid):
        print(version, pid)
        print(self.kwargs)
        print(self.args)
        return Response("...")
