from rest_framework.views import APIView
from rest_framework.response import Response


class UserView(APIView):
    authentication_classes = []
    def get(self, request):
        return Response("用户信息")


class OrderView(APIView):
    def get(self, request):
        message = f"{request.user}的订单信息"
        return Response(message)


class InfoView(APIView):
    def get(self, request):
        message = f"{request.user}的用户信息"
        return Response(message)
