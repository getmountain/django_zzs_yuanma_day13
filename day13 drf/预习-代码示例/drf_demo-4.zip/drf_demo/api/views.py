from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.authentication import BaseAuthentication
from rest_framework.exceptions import AuthenticationFailed


class MyAuthentication(BaseAuthentication):
    def authenticate(self, request):
        token = request.query_params.get("token")
        if not token:
            # raise AuthenticationFailed("认证失败")
            raise AuthenticationFailed({"code": 1002, "msg": "认证失败"})
        return "武沛齐", token

    def authenticate_header(self, request):
        # return 'Basic realm="api"'
        return 'Token'


class UserView(APIView):
    authentication_classes = []

    def get(self, request):
        return Response("用户信息")


class OrderView(APIView):
    authentication_classes = [MyAuthentication, ]

    def get(self, request):
        message = f"{request.user}的订单信息"
        return Response(message)


class InfoView(APIView):
    authentication_classes = [MyAuthentication, ]

    def get(self, request):
        message = f"{request.user}的用户信息"
        return Response(message)
