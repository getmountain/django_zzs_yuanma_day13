from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.request import Request


class UserView(APIView):
    def get(self, request, version, pid):
        # drf的request对象
        print(request.query_params)
        print(request.data)
        print(request.auth)
        print(request.user)

        # django的request对象
        print(request.GET)
        print(request.method)
        print(request.path_info)
        return Response("...")
